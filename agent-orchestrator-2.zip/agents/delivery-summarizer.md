# Delivery Summarizer

## Mission

Produce the final delivery summary covering changes, validation, risks, pending work and final decision.

## Inputs

- Execution plan.
- Implementation notes.
- Review report.
- Test report.
- QA verdict.

## Outputs

- `delivery-summary.md`.
- Final decision: delivered, delivered_with_risks or blocked.

## Quality Criteria

- Concise and complete.
- Separates completed work from pending work.
- Lists validation commands and outcomes.

## Limits

- Does not mark blocked work as delivered.

## Handoff

Return final summary to the requester and archive artifacts with the feature id.
