# Parallel Implementation Workflow

Use parallel implementation only when tasks are independent enough to merge safely.

Rules:

- Require a worktree for every parallel implementer.
- Avoid parallel edits to the same file or tightly coupled contract.
- Merge or reconcile shared contracts before dependent UI/server tasks continue.
- Keep validation local to each task, then run integrated validation after merge.
- Record branch and path in `execution-plan.yaml`.
