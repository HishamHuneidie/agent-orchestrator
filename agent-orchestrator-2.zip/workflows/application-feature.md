# Application Feature Workflow

1. Run `pre-orchestration`.
2. Create `feature-request.yaml` from source documentation.
3. Use `feature-from-docs` to normalize features and acceptance criteria.
4. Use `estimation` to evaluate size, risk and dependencies.
5. Create `execution-plan.yaml`.
6. Use `agent-routing` to assign tasks and decide worktrees.
7. Dispatch implementation tasks.
8. Run review and test workflow.
9. Create delivery summary.

The workflow is complete only when the final decision is recorded.
