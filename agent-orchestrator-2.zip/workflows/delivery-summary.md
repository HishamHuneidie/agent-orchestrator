# Delivery Summary Workflow

1. Gather execution plan, implementation notes, review report, test report and QA verdict.
2. Summarize user-visible and technical changes.
3. List exact validation commands and results.
4. Record residual risks and pending work.
5. Choose final decision: delivered, delivered_with_risks or blocked.
