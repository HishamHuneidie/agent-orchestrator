# Review And Test Workflow

1. Run `pre-review`.
2. Produce `review-report.md`.
3. Fix blocking findings before broad validation.
4. Run `pre-test`.
5. Execute targeted unit tests.
6. Execute e2e tests for critical user flows.
7. Run QA acceptance verification.
8. Produce `test-report.md`.

Delivery is blocked when critical review findings or acceptance failures remain.
