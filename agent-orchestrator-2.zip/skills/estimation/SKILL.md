# Estimation

## Trigger

Use after a feature request exists and before implementation planning.

## Procedure

1. Inspect affected domains and unknowns.
2. Assign size: XS, S, M, L or XL.
3. Assign risk: low, medium or high.
4. List dependencies, sequencing constraints and test impact.
5. Recommend no worktree, recommended worktree or required worktree.

## Expected Result

An estimate with reasoning good enough to drive task splitting and routing.
