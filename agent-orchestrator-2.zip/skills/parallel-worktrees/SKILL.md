# Parallel Worktrees

## Trigger

Use when implementation tasks run in parallel or carry meaningful conflict risk.

## Procedure

1. Confirm Git is initialized with `git rev-parse --is-inside-work-tree`.
2. Choose path `worktrees/<feature-id>/<task-id>`.
3. Create a branch named `agent/<feature-id>/<task-id>`.
4. Create the worktree from the current HEAD.
5. Record branch and path in the execution plan.
6. Clean up only after changes are merged or explicitly abandoned.

## Expected Result

Isolated task workspaces that reduce accidental cross-task conflicts.
