# Code Review

## Trigger

Use after implementation and before test signoff or delivery.

## Procedure

1. Review diff against the execution plan and acceptance criteria.
2. Prioritize correctness, regressions, security, data loss and missing tests.
3. Cite file and line references where possible.
4. Classify findings as critical, high, medium or low.
5. Recommend approve, approve_with_risks or request_changes.

## Expected Result

A review report that lets the orchestrator decide whether to fix, test or deliver.
