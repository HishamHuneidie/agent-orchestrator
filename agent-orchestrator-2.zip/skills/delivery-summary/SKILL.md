# Delivery Summary

## Trigger

Use after implementation, review, tests and QA evidence are available.

## Procedure

1. Summarize completed changes by user-visible outcome.
2. List validation commands and results.
3. Include review and QA decision.
4. Record known risks, follow-ups and blocked items.
5. State final decision.

## Expected Result

A concise final artifact suitable for handoff to the requester.
