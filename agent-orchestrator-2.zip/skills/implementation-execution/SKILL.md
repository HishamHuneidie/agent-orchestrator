# Implementation Execution

## Trigger

Use when an implementer receives an `agent-task.yaml`.

## Procedure

1. Read the task, acceptance criteria and relevant repository files.
2. Confirm expected files and validation commands.
3. Implement only the assigned scope.
4. Add or update tests proportional to risk.
5. Run validation commands when feasible.
6. Report touched files, commands, results and blockers.

## Expected Result

A scoped implementation ready for review, with enough evidence for downstream validation.
