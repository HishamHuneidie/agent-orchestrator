# Agent Routing

## Trigger

Use when tasks need agent assignment, sequencing, parallelism or worktree decisions.

## Procedure

1. Classify each task by domain: backend, frontend, fullstack, review, unit, e2e or QA.
2. Choose the narrowest capable agent.
3. Mark dependencies and tasks that can run concurrently.
4. Require worktrees for parallel implementers.
5. Prefer sequential execution when tasks touch the same files or contracts.

## Expected Result

A dispatch plan with assigned agents, order, dependency edges and worktree decisions.
