# Feature From Docs

## Trigger

Use when source documentation, notes or product requirements must become implementable feature requests.

## Procedure

1. Identify the primary user goal.
2. Extract candidate features and merge duplicates.
3. Convert each feature into testable acceptance criteria.
4. Record assumptions, constraints and out-of-scope items.
5. Populate `feature-request.yaml`.

## Expected Result

A feature request that an estimator can evaluate without re-reading all source material.
