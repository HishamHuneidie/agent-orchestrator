# Test Validation

## Trigger

Use when implementation needs unit, e2e or QA validation.

## Procedure

1. Map acceptance criteria to validation methods.
2. Run existing targeted tests first.
3. Add missing unit or e2e tests when required by risk.
4. Record exact commands and outcomes.
5. Mark gaps clearly when validation is manual, blocked or partial.

## Expected Result

A test report that distinguishes verified behavior from untested risk.
