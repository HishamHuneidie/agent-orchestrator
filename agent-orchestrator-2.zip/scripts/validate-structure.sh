#!/usr/bin/env bash
set -u

missing=0

require_file() {
  if [ ! -f "$1" ]; then
    printf 'missing file: %s\n' "$1" >&2
    missing=1
  fi
}

require_dir() {
  if [ ! -d "$1" ]; then
    printf 'missing directory: %s\n' "$1" >&2
    missing=1
  fi
}

for dir in agents docs hooks schemas scripts skills templates workflows; do
  require_dir "$dir"
done

require_file README.md
require_file orchestrator.yaml
require_file tree.example

for file in \
  agents/backend-engineer.md \
  agents/code-reviewer.md \
  agents/delivery-summarizer.md \
  agents/e2e-test-engineer.md \
  agents/estimator.md \
  agents/feature-analyst.md \
  agents/frontend-engineer.md \
  agents/fullstack-engineer.md \
  agents/implementation-planner.md \
  agents/orchestrator.md \
  agents/qa-verifier.md \
  agents/unit-test-engineer.md \
  docs/agent-lifecycle.md \
  docs/architecture.md \
  docs/operating-manual.md \
  docs/worktree-strategy.md \
  hooks/post-agent-dispatch.md \
  hooks/post-delivery.md \
  hooks/pre-agent-dispatch.md \
  hooks/pre-orchestration.md \
  hooks/pre-review.md \
  hooks/pre-test.md \
  schemas/agent-task.schema.yaml \
  schemas/delivery-summary.schema.yaml \
  schemas/execution-plan.schema.yaml \
  schemas/feature-request.schema.yaml \
  schemas/review-report.schema.yaml \
  schemas/test-report.schema.yaml \
  scripts/cleanup-worktree.sh \
  scripts/create-worktree.sh \
  scripts/orchestrate.sh \
  scripts/validate-structure.sh \
  skills/agent-routing/SKILL.md \
  skills/code-review/SKILL.md \
  skills/delivery-summary/SKILL.md \
  skills/estimation/SKILL.md \
  skills/feature-from-docs/SKILL.md \
  skills/implementation-execution/SKILL.md \
  skills/parallel-worktrees/SKILL.md \
  skills/test-validation/SKILL.md \
  templates/agent-task.yaml \
  templates/delivery-summary.md \
  templates/execution-plan.yaml \
  templates/feature-request.yaml \
  templates/review-report.md \
  templates/test-report.md \
  workflows/application-feature.md \
  workflows/delivery-summary.md \
  workflows/parallel-implementation.md \
  workflows/review-and-test.md; do
  require_file "$file"
done

if [ "$missing" -ne 0 ]; then
  printf 'structure validation failed\n' >&2
  exit 1
fi

printf 'structure validation passed\n'
