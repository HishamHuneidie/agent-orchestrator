# Agent Orchestrator

Sistema portable de orquestacion de agentes para convertir documentacion de producto en features implementables, planes de ejecucion, tareas asignables, revisiones, pruebas y resumen de entrega.

La primera version es deliberadamente basada en Markdown, YAML y shell. No invoca agentes automaticamente; define contratos claros para que Codex, otros CLIs o personas puedan ejecutar el flujo de forma repetible.

## Flujo Principal

1. Leer documentacion fuente y completar `templates/feature-request.yaml`.
2. Extraer features, criterios de aceptacion, restricciones y fuera de alcance.
3. Estimar complejidad, riesgo, dependencias y tamano.
4. Crear `templates/execution-plan.yaml` para fases, tareas, agentes y validaciones.
5. Seleccionar agentes desde `agents/` usando `skills/agent-routing/SKILL.md`.
6. Decidir uso de worktrees segun riesgo y paralelismo.
7. Ejecutar implementacion con contratos de tarea.
8. Revisar codigo, ejecutar pruebas unitarias, e2e y QA.
9. Cerrar con `templates/delivery-summary.md`.

## Uso Rapido

```sh
scripts/validate-structure.sh
scripts/orchestrate.sh templates/feature-request.yaml
```

Para una tarea paralela con worktree:

```sh
scripts/create-worktree.sh feature-login backend-api
```

La limpieza de worktrees es explicita:

```sh
scripts/cleanup-worktree.sh feature-login backend-api
```

## Politica de Worktrees

- No usar worktree para documentacion, estimacion o tareas secuenciales pequenas.
- Usar worktree obligatorio para implementadores en paralelo.
- Usar worktree recomendado para cambios grandes, migraciones, refactors o alto riesgo de conflicto.
- Fallar con mensaje claro cuando Git no este inicializado correctamente.

## Estructura

- `orchestrator.yaml`: configuracion central.
- `agents/`: perfiles de agentes.
- `skills/`: procedimientos reutilizables.
- `hooks/`: puntos de control del proceso.
- `workflows/`: secuencias completas.
- `schemas/`: contratos YAML.
- `templates/`: archivos rellenables para operacion manual.
- `scripts/`: validacion y utilidades de worktree.
