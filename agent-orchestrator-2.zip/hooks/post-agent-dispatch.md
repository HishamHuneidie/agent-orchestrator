# Post-Agent Dispatch Hook

Capture after an agent finishes:

- Agent name and task id.
- Summary of completed work.
- Files touched.
- Commands run and results.
- Blockers, assumptions and follow-up needs.
- Handoff target.
