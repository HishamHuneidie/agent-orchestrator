# Pre-Review Hook

Validate before review:

- Implementation is complete enough for review.
- Diff is available.
- Acceptance criteria and execution plan are accessible.
- Tests already run are recorded.
- Known incomplete items are clearly marked.
