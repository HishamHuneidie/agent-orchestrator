# Pre-Test Hook

Validate before testing:

- Environment setup is documented.
- Required services and dependencies are available.
- Commands are specific and reproducible.
- Expected coverage is mapped to acceptance criteria.
- Known blockers are listed before execution.
