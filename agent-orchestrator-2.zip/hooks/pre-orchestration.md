# Pre-Orchestration Hook

Validate before starting:

- Objective is explicit.
- Source documentation is available or gaps are listed.
- Constraints, deadlines and out-of-scope items are captured.
- Repository status and target branch are known when code changes are expected.
- `feature-request.yaml` can be created from the available context.
