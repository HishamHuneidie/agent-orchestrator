# Pre-Agent Dispatch Hook

Validate before assigning work:

- Task id is stable.
- Assigned agent matches task domain.
- Inputs, expected files and success criteria are present.
- Dependencies are complete or intentionally deferred.
- Worktree path is present when required.
- Validation commands are documented.
