# Post-Delivery Hook

Validate final delivery:

- Review report exists.
- Test report exists.
- QA verdict is captured.
- Delivery summary includes changes, validation, risks and pending items.
- Final decision is one of delivered, delivered_with_risks or blocked.
